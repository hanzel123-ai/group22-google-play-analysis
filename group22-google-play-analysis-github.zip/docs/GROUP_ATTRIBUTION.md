# Group 22 Attribution

This CA6002 assignment is a collaborative project by Group 22. Repository ownership does not imply sole authorship of the analysis, code, visualisations or presentation.

The supplied presentation identifies these section responsibilities:

| Member, as written in the presentation | Presentation sections |
| --- | --- |
| LIU YU HAN | Research framing, dataset exploration, cleaning and initial rating analysis (slides 2–6) |
| LIU XUANHUI | Correlation analysis, preprocessing, model comparison and tuning (slides 7–10) |
| LIU YAODONG | Learning curves, evaluation, segmented errors and predictive importance (slides 11–14) |
| LIU YUTONG | Visual storytelling, recommendations and conclusion (slides 15–19) |

These are presentation section assignments, not independently verified records of who wrote each code cell or performed each experiment. Personal code contributions are not inferred.

Repository preparation adds documentation, groups supplied artifacts into folders, renames files for navigation, clears notebook outputs, and repairs initialization order and data paths. It does not claim new authorship of the underlying group assignment or new model results.
